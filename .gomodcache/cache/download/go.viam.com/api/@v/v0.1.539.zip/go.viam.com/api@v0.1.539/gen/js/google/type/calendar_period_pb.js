// source: google/type/calendar_period.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {missingRequire} reports error on implicit type usages.
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!
/* eslint-disable */
// @ts-nocheck

var jspb = require('google-protobuf');
var goog = jspb;
var global = (function() { return this || window || global || self || Function('return this')(); }).call(null);

goog.exportSymbol('proto.google.type.CalendarPeriod', null, global);
/**
 * @enum {number}
 */
proto.google.type.CalendarPeriod = {
  CALENDAR_PERIOD_UNSPECIFIED: 0,
  DAY: 1,
  WEEK: 2,
  FORTNIGHT: 3,
  MONTH: 4,
  QUARTER: 5,
  HALF: 6,
  YEAR: 7
};

goog.object.extend(exports, proto.google.type);

// package: viam.component.audioin.v1
// file: component/audioin/v1/audioin.proto

import * as component_audioin_v1_audioin_pb from "../../../component/audioin/v1/audioin_pb";
import * as common_v1_common_pb from "../../../common/v1/common_pb";
import {grpc} from "@improbable-eng/grpc-web";

type AudioInServiceGetAudio = {
  readonly methodName: string;
  readonly service: typeof AudioInService;
  readonly requestStream: false;
  readonly responseStream: true;
  readonly requestType: typeof component_audioin_v1_audioin_pb.GetAudioRequest;
  readonly responseType: typeof component_audioin_v1_audioin_pb.GetAudioResponse;
};

type AudioInServiceGetProperties = {
  readonly methodName: string;
  readonly service: typeof AudioInService;
  readonly requestStream: false;
  readonly responseStream: false;
  readonly requestType: typeof common_v1_common_pb.GetPropertiesRequest;
  readonly responseType: typeof common_v1_common_pb.GetPropertiesResponse;
};

type AudioInServiceDoCommand = {
  readonly methodName: string;
  readonly service: typeof AudioInService;
  readonly requestStream: false;
  readonly responseStream: false;
  readonly requestType: typeof common_v1_common_pb.DoCommandRequest;
  readonly responseType: typeof common_v1_common_pb.DoCommandResponse;
};

type AudioInServiceGetStatus = {
  readonly methodName: string;
  readonly service: typeof AudioInService;
  readonly requestStream: false;
  readonly responseStream: false;
  readonly requestType: typeof common_v1_common_pb.GetStatusRequest;
  readonly responseType: typeof common_v1_common_pb.GetStatusResponse;
};

type AudioInServiceGetGeometries = {
  readonly methodName: string;
  readonly service: typeof AudioInService;
  readonly requestStream: false;
  readonly responseStream: false;
  readonly requestType: typeof common_v1_common_pb.GetGeometriesRequest;
  readonly responseType: typeof common_v1_common_pb.GetGeometriesResponse;
};

export class AudioInService {
  static readonly serviceName: string;
  static readonly GetAudio: AudioInServiceGetAudio;
  static readonly GetProperties: AudioInServiceGetProperties;
  static readonly DoCommand: AudioInServiceDoCommand;
  static readonly GetStatus: AudioInServiceGetStatus;
  static readonly GetGeometries: AudioInServiceGetGeometries;
}

export type ServiceError = { message: string, code: number; metadata: grpc.Metadata }
export type Status = { details: string, code: number; metadata: grpc.Metadata }

interface UnaryResponse {
  cancel(): void;
}
interface ResponseStream<T> {
  cancel(): void;
  on(type: 'data', handler: (message: T) => void): ResponseStream<T>;
  on(type: 'end', handler: (status?: Status) => void): ResponseStream<T>;
  on(type: 'status', handler: (status: Status) => void): ResponseStream<T>;
}
interface RequestStream<T> {
  write(message: T): RequestStream<T>;
  end(): void;
  cancel(): void;
  on(type: 'end', handler: (status?: Status) => void): RequestStream<T>;
  on(type: 'status', handler: (status: Status) => void): RequestStream<T>;
}
interface BidirectionalStream<ReqT, ResT> {
  write(message: ReqT): BidirectionalStream<ReqT, ResT>;
  end(): void;
  cancel(): void;
  on(type: 'data', handler: (message: ResT) => void): BidirectionalStream<ReqT, ResT>;
  on(type: 'end', handler: (status?: Status) => void): BidirectionalStream<ReqT, ResT>;
  on(type: 'status', handler: (status: Status) => void): BidirectionalStream<ReqT, ResT>;
}

export class AudioInServiceClient {
  readonly serviceHost: string;

  constructor(serviceHost: string, options?: grpc.RpcOptions);
  getAudio(requestMessage: component_audioin_v1_audioin_pb.GetAudioRequest, metadata?: grpc.Metadata): ResponseStream<component_audioin_v1_audioin_pb.GetAudioResponse>;
  getProperties(
    requestMessage: common_v1_common_pb.GetPropertiesRequest,
    metadata: grpc.Metadata,
    callback: (error: ServiceError|null, responseMessage: common_v1_common_pb.GetPropertiesResponse|null) => void
  ): UnaryResponse;
  getProperties(
    requestMessage: common_v1_common_pb.GetPropertiesRequest,
    callback: (error: ServiceError|null, responseMessage: common_v1_common_pb.GetPropertiesResponse|null) => void
  ): UnaryResponse;
  doCommand(
    requestMessage: common_v1_common_pb.DoCommandRequest,
    metadata: grpc.Metadata,
    callback: (error: ServiceError|null, responseMessage: common_v1_common_pb.DoCommandResponse|null) => void
  ): UnaryResponse;
  doCommand(
    requestMessage: common_v1_common_pb.DoCommandRequest,
    callback: (error: ServiceError|null, responseMessage: common_v1_common_pb.DoCommandResponse|null) => void
  ): UnaryResponse;
  getStatus(
    requestMessage: common_v1_common_pb.GetStatusRequest,
    metadata: grpc.Metadata,
    callback: (error: ServiceError|null, responseMessage: common_v1_common_pb.GetStatusResponse|null) => void
  ): UnaryResponse;
  getStatus(
    requestMessage: common_v1_common_pb.GetStatusRequest,
    callback: (error: ServiceError|null, responseMessage: common_v1_common_pb.GetStatusResponse|null) => void
  ): UnaryResponse;
  getGeometries(
    requestMessage: common_v1_common_pb.GetGeometriesRequest,
    metadata: grpc.Metadata,
    callback: (error: ServiceError|null, responseMessage: common_v1_common_pb.GetGeometriesResponse|null) => void
  ): UnaryResponse;
  getGeometries(
    requestMessage: common_v1_common_pb.GetGeometriesRequest,
    callback: (error: ServiceError|null, responseMessage: common_v1_common_pb.GetGeometriesResponse|null) => void
  ): UnaryResponse;
}


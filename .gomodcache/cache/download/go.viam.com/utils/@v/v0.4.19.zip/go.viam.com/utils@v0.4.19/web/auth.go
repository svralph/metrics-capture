package web

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/coreos/go-oidc/v3/oidc"
	"go.opencensus.io/trace"
	"goji.io"
	"goji.io/pat"
	"golang.org/x/oauth2"

	"go.viam.com/utils"
)

// AuthProviderConfig config options with constants that will probably need to be manually configured after
// retrieval from the auth provider web UI or API (e.g. for FusionAuth).
type AuthProviderConfig struct {
	Domain                string
	ClientID              string
	Secret                string
	BaseURL               string
	PostLogoutRedirectURL string
	EnableTest            bool
}

// AuthProvider should include all state that we need to share with auth callbacks or to make customizations on the
// internals of the specific auth mechanisms we implement for a particular provider.
type AuthProvider struct {
	io.Closer

	config   AuthProviderConfig
	sessions *SessionManager

	oidcConfig    *oidc.Config
	authConfig    oauth2.Config
	httpTransport *http.Transport

	redirectURL string

	// important to have different auth providers have different cookie name so that we force
	// a re-login and throw away old browser state if we migrate auth providers
	stateCookieName   string
	stateCookieMaxAge time.Duration
}

const (
	// ViamTokenCookie is the cookie name for an authenticated access token
	//nolint:gosec
	ViamTokenCookie string = "viam.auth.token"
	// ViamRefreshCookie is the cookie name for an authenticated refresh token.
	ViamRefreshCookie string = "viam.auth.refresh"
	// ViamExpiryCookie is the cookie name for an authenticated token's expiry.
	ViamExpiryCookie string = "viam.auth.expiry"
)

// Close called by io.Closer.
func (s *AuthProvider) Close() error {
	s.httpTransport.CloseIdleConnections()
	return nil
}

func (s *AuthProvider) newAuthProvider(ctx context.Context) (*oidc.Provider, error) {
	p, err := oidc.NewProvider(ctx, s.config.Domain)
	if err != nil {
		return nil, fmt.Errorf("failed to get provider: %w", err)
	}
	return p, nil
}

// InstallFusionAuth does initial setup and installs routes for FusionAuth.
func InstallFusionAuth(
	ctx context.Context,
	mux *goji.Mux,
	sessions *SessionManager,
	config AuthProviderConfig,
	logger utils.ZapCompatibleLogger,
) (io.Closer, error) {
	config.PostLogoutRedirectURL = "post_logout_redirect_uri"
	authProvider, err := installAuthProvider(
		ctx,
		sessions,
		config,
		"/callback",
		"fa_redirect_state")
	if err != nil {
		return nil, err
	}

	installAuthProviderRoutes(
		mux,
		authProvider,
		"/oauth2/logout",
		authProvider.redirectURL,
		authProvider.stateCookieName,
		authProvider.stateCookieMaxAge,
		logger)

	return authProvider, nil
}

func installAuthProvider(
	ctx context.Context,
	sessions *SessionManager,
	config AuthProviderConfig,
	redirectURL string,
	providerCookieName string,
) (*AuthProvider, error) {
	if config.Domain == "" {
		return nil, errors.New("need a domain for auth provider")
	}

	if config.BaseURL == "" {
		return nil, errors.New("need a base URL for auth provider")
	}

	if sessions == nil {
		return nil, errors.New("sessions needed for auth provider")
	}

	if config.PostLogoutRedirectURL == "" {
		return nil, errors.New("need a post logout redirect url")
	}

	state := &AuthProvider{
		config:            config,
		sessions:          sessions,
		redirectURL:       redirectURL,
		stateCookieName:   providerCookieName,
		stateCookieMaxAge: time.Minute * 10,
	}

	state.oidcConfig = &oidc.Config{
		ClientID: config.ClientID,
	}

	var httpTransport http.Transport
	ctx = oidc.ClientContext(ctx, &http.Client{Transport: &httpTransport})

	p, err := state.newAuthProvider(ctx)
	if err != nil {
		httpTransport.CloseIdleConnections()
		return nil, err
	}
	state.httpTransport = &httpTransport

	state.authConfig = oauth2.Config{
		ClientID:     config.ClientID,
		ClientSecret: config.Secret,
		RedirectURL:  config.BaseURL + redirectURL,
		Endpoint:     p.Endpoint(),
		Scopes:       []string{oidc.ScopeOpenID, "profile", "email"},
	}

	return state, nil
}

func installAuthProviderRoutes(
	mux *goji.Mux,
	authProvider *AuthProvider,
	providerLogoutURL string,
	redirectURL string,
	redirectStateCookieName string,
	redirectStateCookieMaxAge time.Duration,
	logger utils.ZapCompatibleLogger,
) {
	mux.Handle(pat.New("/login"), &loginHandler{
		state:                     authProvider,
		logger:                    logger,
		redirectStateCookieName:   redirectStateCookieName,
		redirectStateCookieMaxAge: redirectStateCookieMaxAge,
	})
	mux.Handle(pat.New(redirectURL), &callbackHandler{
		authProvider,
		logger,
		redirectStateCookieName,
	})
	mux.Handle(pat.New("/logout"), &logoutHandler{
		state:             authProvider,
		logger:            logger,
		providerLogoutURL: providerLogoutURL,
	})
	mux.Handle(pat.New("/token"), &tokenHandler{
		authProvider,
		logger,
		redirectStateCookieName,
		redirectStateCookieMaxAge,
	})

	if authProvider.config.EnableTest {
		mux.Handle(pat.New("/token-callback"), &tokenCallbackHandler{authProvider, logger})
	}
}

type callbackHandler struct {
	state                   *AuthProvider
	logger                  utils.ZapCompatibleLogger
	redirectStateCookieName string
}

func (h *callbackHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 10*time.Second)
	defer cancel()

	ctx, span := trace.StartSpan(ctx, r.URL.Path)
	defer span.End()

	stateCookie, err := r.Cookie(h.redirectStateCookieName)
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusTemporaryRedirect)
		return
	}

	http.SetCookie(w, &http.Cookie{
		Name:     h.redirectStateCookieName,
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		Secure:   r.TLS != nil,
		SameSite: http.SameSiteLaxMode,
		HttpOnly: true,
	})

	stateParts := strings.SplitN(stateCookie.Value, ":", 2)
	if len(stateParts) != 2 {
		w.WriteHeader(http.StatusBadRequest)
		_, err := w.Write([]byte("invalid state parameter"))
		utils.UncheckedError(err)
		return
	}

	session, err := h.state.sessions.store.Get(r.Context(), stateParts[0])
	if HandleError(w, err, h.logger, "getting session") {
		return
	}

	if r.URL.Query().Get("state") != stateParts[1] {
		http.Error(w, "Invalid state parameter", http.StatusBadRequest)
		return
	}

	token, err := h.state.authConfig.Exchange(ctx, r.URL.Query().Get("code"))
	if err != nil {
		h.logger.Debugw("no token found", "error", err)
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	session, err = verifyAndSaveToken(ctx, h.state, session, token)
	if HandleError(w, err, h.logger) {
		return
	}

	backto, _ := session.Data["backto"].(string)
	if len(backto) == 0 {
		backto = "/"
	}

	session.Data["backto"] = ""
	err = session.Save(ctx, r, w)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	http.SetCookie(w, &http.Cookie{
		Name:     ViamTokenCookie,
		Value:    token.AccessToken,
		Path:     "/",
		Expires:  token.Expiry,
		Secure:   r.TLS != nil,
		SameSite: http.SameSiteLaxMode,
		HttpOnly: true,
	})

	http.SetCookie(w, &http.Cookie{
		Name:     ViamRefreshCookie,
		Value:    token.RefreshToken,
		Path:     "/",
		Expires:  token.Expiry,
		Secure:   r.TLS != nil,
		SameSite: http.SameSiteLaxMode,
		HttpOnly: true,
	})

	http.SetCookie(w, &http.Cookie{
		Name:     ViamExpiryCookie,
		Value:    token.Expiry.Format(time.RFC3339),
		Path:     "/",
		Expires:  token.Expiry,
		Secure:   r.TLS != nil,
		SameSite: http.SameSiteLaxMode,
		HttpOnly: true,
	})

	_, err = w.Write([]byte(fmt.Sprintf(`<html>
<head>
<meta http-equiv="refresh" content="0;URL='%s'"/>
</head>
</html>
`, backto)))
	utils.UncheckedError(err)
}

// Handle programmatically generated access + id tokens
// Currently used only in testing.
type tokenCallbackHandler struct {
	state  *AuthProvider
	logger utils.ZapCompatibleLogger
}

func (h *tokenCallbackHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 10*time.Second)
	defer cancel()

	ctx, span := trace.StartSpan(ctx, r.URL.Path)
	defer span.End()

	session, err := h.state.sessions.Get(r, true)
	if HandleError(w, err, h.logger, "getting session") {
		return
	}

	if r.Method != http.MethodPost {
		http.Error(w, errors.New("method not allowed").Error(), http.StatusMethodNotAllowed)
		return
	}

	defer utils.UncheckedErrorFunc(r.Body.Close)
	bodyBytes, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, errors.New("unable to read message body").Error(), http.StatusBadRequest)
		return
	}

	jsonToken := map[string]interface{}{}
	if err := json.Unmarshal(bodyBytes, &jsonToken); HandleError(w, err, h.logger, "reading token") {
		return
	}

	token := &oauth2.Token{}
	if err := json.Unmarshal(bodyBytes, &token); HandleError(w, err, h.logger, "reading token") {
		return
	}

	if e, ok := jsonToken["expires_in"].(float64); !ok {
		HandleError(w, errors.New("could not determine token expiry"), h.logger, "reading token")
		return
	} else if e != 0 {
		token.Expiry = time.Now().Add(time.Duration(e) * time.Second)
	}

	token = token.WithExtra(jsonToken)

	session, err = verifyAndSaveToken(ctx, h.state, session, token)
	if HandleError(w, err, h.logger) {
		return
	}

	backto, _ := session.Data["backto"].(string)
	if len(backto) == 0 {
		backto = "/"
	}

	session.Data["backto"] = ""
	err = session.Save(ctx, r, w)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, backto, http.StatusSeeOther)
}

func verifyAndSaveToken(ctx context.Context, state *AuthProvider, session *Session, token *oauth2.Token) (*Session, error) {
	rawIDToken, ok := token.Extra("id_token").(string)
	if !ok {
		return nil, errors.New("no id_token field in oauth2 token")
	}

	p, err := state.newAuthProvider(ctx)
	if err != nil {
		return nil, err
	}

	idToken, err := p.Verifier(state.oidcConfig).Verify(ctx, rawIDToken)
	if err != nil {
		return nil, errors.New("failed to verify ID Token: " + err.Error())
	}

	// Getting now the userInfo
	var profile map[string]interface{}
	if err := idToken.Claims(&profile); err != nil {
		return nil, err
	}

	session.Data["id_token"] = rawIDToken
	session.Data[accessTokenSessionDataField] = token.AccessToken
	session.Data["profile"] = profile

	return session, nil
}

// --------------------------------.
type tokenHandler struct {
	state                     *AuthProvider
	logger                    utils.ZapCompatibleLogger
	redirectStateCookieName   string
	redirectStateCookieMaxAge time.Duration
}

type tokenResponse struct {
	AccessToken  string `json:"accessToken"`
	RefreshToken string `json:"refreshToken"`
	Expiry       string `json:"expiry"`
}

func getBearerToken(req *http.Request) string {
	authHeader := req.Header.Get("Authorization")
	if authHeader == "" {
		return ""
	}

	parts := strings.Split(authHeader, " ")
	if len(parts) == 2 && parts[0] == "Bearer" {
		return parts[1]
	}

	return ""
}

// getAuthCookieValues reads the authentication cookie values as a /token response
// before clearing the cookies.
func getAndClearAuthCookieValues(w http.ResponseWriter, r *http.Request) *tokenResponse {
	token, err := r.Cookie(ViamTokenCookie)
	if err != nil || token.Value == "" {
		return nil
	}

	refresh, err := r.Cookie(ViamRefreshCookie)
	// TODO: Check if refresh is empty when implemented, always empty now
	if err != nil {
		return nil
	}

	expiry, err := r.Cookie(ViamExpiryCookie)
	if err != nil || expiry.Value == "" {
		return nil
	}

	http.SetCookie(w, &http.Cookie{
		Name:     ViamTokenCookie,
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		SameSite: http.SameSiteLaxMode,
		HttpOnly: true,
	})

	http.SetCookie(w, &http.Cookie{
		Name:     ViamRefreshCookie,
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		SameSite: http.SameSiteLaxMode,
		HttpOnly: true,
	})

	http.SetCookie(w, &http.Cookie{
		Name:     ViamExpiryCookie,
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		SameSite: http.SameSiteLaxMode,
		HttpOnly: true,
	})

	return &tokenResponse{
		AccessToken:  token.Value,
		RefreshToken: refresh.Value,
		Expiry:       expiry.Value,
	}
}

func (h *tokenHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 10*time.Second)
	defer cancel()

	_, span := trace.StartSpan(ctx, r.URL.Path)
	defer span.End()

	data := getAndClearAuthCookieValues(w, r)

	// handle incoming login request with cookies
	if data != nil {
		w.Header().Set("Content-Type", "application/json")
		response, err := json.Marshal(data)
		if err != nil {
			temp := errors.New("failed to verify marshal token data: " + err.Error())
			w.WriteHeader(http.StatusInternalServerError)
			_, err = w.Write([]byte(temp.Error()))
			if err != nil {
				utils.UncheckedError(err)
			}
			h.logger.Error(temp)
			return
		}

		_, err = w.Write(response)
		utils.UncheckedError(err)
		return
	}

	// user calls with no token in the header, no cookies exist
	// - return a bad request 400
	current := getBearerToken(r)
	if current == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	// user calls with an invalid token in the header, no cookies exist
	// - return an unauthenticated error 401
	isValid := h.state.sessions.HasSessionWithAccessToken(ctx, current)
	if !isValid {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	// user calls with a valid token in the header, no cookies exist
	// - return a no content 204 response
	w.WriteHeader(http.StatusNoContent)
}

// --------------------------------

type loginHandler struct {
	state                     *AuthProvider
	logger                    utils.ZapCompatibleLogger
	redirectStateCookieName   string
	redirectStateCookieMaxAge time.Duration
}

func (h *loginHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 10*time.Second)
	defer cancel()

	_, span := trace.StartSpan(ctx, r.URL.Path)
	defer span.End()

	// Generate random state
	b := make([]byte, 32)
	_, err := rand.Read(b)
	if HandleError(w, err, h.logger, "error getting random number") {
		return
	}
	state := base64.StdEncoding.EncodeToString(b)

	session, err := h.state.sessions.Get(r, true)
	if HandleError(w, err, h.logger, "error getting session") {
		return
	}
	http.SetCookie(w, &http.Cookie{
		Name:     h.redirectStateCookieName,
		Value:    fmt.Sprintf("%s:%s", session.id, state),
		Path:     "/",
		MaxAge:   int(h.redirectStateCookieMaxAge.Seconds()),
		Secure:   r.TLS != nil,
		SameSite: http.SameSiteLaxMode,
		HttpOnly: true,
	})

	if r.FormValue("backto") != "" {
		backto := r.FormValue("backto")
		if IsValidBacktoURL(backto) {
			session.Data["backto"] = backto
		}
	}

	if session.Data["backto"] == "" {
		session.Data["backto"] = r.Header.Get("Referer")
	}
	err = session.Save(ctx, r, w)
	if HandleError(w, err, h.logger, "error saving session") {
		return
	}

	redirect := r.URL.Query().Get("redirect_uri")
	if redirect != "" {
		config := h.state.authConfig
		config.RedirectURL = redirect
		http.Redirect(w, r, config.AuthCodeURL(state), http.StatusTemporaryRedirect)
		return
	}

	http.Redirect(w, r, h.state.authConfig.AuthCodeURL(state), http.StatusTemporaryRedirect)
}

// --------------------------------

type logoutHandler struct {
	state             *AuthProvider
	logger            utils.ZapCompatibleLogger
	providerLogoutURL string
}

func (h *logoutHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 10*time.Second)
	defer cancel()

	ctx, span := trace.StartSpan(ctx, r.URL.Path)
	defer span.End()

	logoutURL, err := url.Parse(h.state.config.Domain)
	if HandleError(w, err, h.logger, "internal config error parsing domain") {
		return
	}

	logoutURL.Path = h.providerLogoutURL
	parameters := url.Values{}

	parameters.Add(h.state.config.PostLogoutRedirectURL, h.state.config.BaseURL)
	parameters.Add("client_id", h.state.config.ClientID)
	logoutURL.RawQuery = parameters.Encode()

	h.state.sessions.DeleteSession(ctx, r, w)
	http.Redirect(w, r, logoutURL.String(), http.StatusTemporaryRedirect)
}
